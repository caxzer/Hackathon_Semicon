/*******************************************************************************
 * File Name: cycfg_peripheral_clocks.c
 *
 * Description:
 * Peripheral clock divider configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.90.0
 * device-db 4.41.0.11271
 * mtb-dsl-psc3m6 1.1.0.359
 *
 *******************************************************************************
 * Copyright 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#include "cycfg_peripheral_clocks.h"

#if defined (CY_USING_HAL)
const cyhal_resource_inst_t peri_0_group_0_div_16_0_obj =
{
    .type = CYHAL_RSC_CLOCK,
    .block_num = peri_0_group_0_div_16_0_HW,
    .channel_num = peri_0_group_0_div_16_0_NUM,
};
const cyhal_resource_inst_t peri_0_group_4_div_16_5_0_obj =
{
    .type = CYHAL_RSC_CLOCK,
    .block_num = peri_0_group_4_div_16_5_0_HW,
    .channel_num = peri_0_group_4_div_16_5_0_NUM,
};
#endif /* defined (CY_USING_HAL) */

void init_cycfg_peripheral_clocks(void)
{
    Cy_SysClk_PeriPclkDisableDivider((en_clk_dst_t)PERI_0_GROUP_0_DIV_16_0_GRP_NUM, CY_SYSCLK_DIV_16_BIT, 0U);
    Cy_SysClk_PeriPclkSetDivider((en_clk_dst_t)PERI_0_GROUP_0_DIV_16_0_GRP_NUM, CY_SYSCLK_DIV_16_BIT, 0U, 17999U);
    Cy_SysClk_PeriPclkEnableDivider((en_clk_dst_t)PERI_0_GROUP_0_DIV_16_0_GRP_NUM, CY_SYSCLK_DIV_16_BIT, 0U);
    Cy_SysClk_PeriPclkDisableDivider((en_clk_dst_t)PERI_0_GROUP_4_DIV_16_5_0_GRP_NUM, CY_SYSCLK_DIV_16_5_BIT, 0U);
    Cy_SysClk_PeriPclkSetFracDivider((en_clk_dst_t)PERI_0_GROUP_4_DIV_16_5_0_GRP_NUM, CY_SYSCLK_DIV_16_5_BIT, 0U, 107U, 16U);
    Cy_SysClk_PeriPclkEnableDivider((en_clk_dst_t)PERI_0_GROUP_4_DIV_16_5_0_GRP_NUM, CY_SYSCLK_DIV_16_5_BIT, 0U);
}
void reserve_cycfg_peripheral_clocks(void)
{
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&peri_0_group_0_div_16_0_obj);
    cyhal_hwmgr_reserve(&peri_0_group_4_div_16_5_0_obj);
#endif /* defined (CY_USING_HAL) */
}
