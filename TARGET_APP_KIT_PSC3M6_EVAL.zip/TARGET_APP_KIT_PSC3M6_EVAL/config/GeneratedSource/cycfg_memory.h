/*******************************************************************************
 * File Name: cycfg_memory.h
 *
 * Description:
 * Memory configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.90.0
 * device-db 4.41.0.11271
 * mtb-dsl-psc3m6 1.1.0.359
 *
 *******************************************************************************
 * Copyright 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_MEMORY_H)
#define CYCFG_MEMORY_H

#include "cycfg_notices.h"

#if defined(COMPONENT_CM33_0) && defined(COMPONENT_SECURE_DEVICE)
#include "cymem_CM33_0_S.h"
#endif /* defined(COMPONENT_CM33_0) && defined(COMPONENT_SECURE_DEVICE) */

#if defined(COMPONENT_CM33_0) && defined(COMPONENT_NON_SECURE_DEVICE)
#include "cymem_CM33_0.h"
#endif /* defined(COMPONENT_CM33_0) && defined(COMPONENT_NON_SECURE_DEVICE) */

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#define vres_0_memory_region_data_0_ENABLED 1U
#define vres_0_memory_region_data_1_ENABLED 1U
#define vres_0_memory_region_data_2_ENABLED 1U
#define vres_0_memory_region_data_3_ENABLED 1U
#define vres_0_memory_0_ENABLED 1U

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_MEMORY_H */
